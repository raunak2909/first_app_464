
import 'practise.dart';

void main(){

  print('Enter your age: ');
  int age = int.parse(getValue());

  print("Your age: $age");

}